// import 'package:flutter/material.dart';
// import 'package:shoes_store/model/order.dart';
// import 'package:shoes_store/screen/order_confirmation_screen.dart';

// class MyOrderScreen extends StatelessWidget {
//   final List<Order> pastOrders;

//   const MyOrderScreen({Key? key, required this.pastOrders}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("My Orders"),
//         leading: IconButton(
//           icon: const Icon(Icons.arrow_back),
//           onPressed: () => Navigator.pop(context),
//         ),
//       ),
//       body:
//           pastOrders.isEmpty
//               ? const Center(
//                 child: Text(
//                   "No orders found.",
//                   style: TextStyle(fontSize: 16, color: Colors.grey),
//                 ),
//               )
//               : ListView.builder(
//                 itemCount: pastOrders.length,
//                 itemBuilder: (context, index) {
//                   final order = pastOrders[index];
//                   return Card(
//                     margin: const EdgeInsets.all(12),
//                     elevation: 2,
//                     shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(10),
//                     ),
//                     child: ListTile(
//                       contentPadding: const EdgeInsets.symmetric(
//                         vertical: 12,
//                         horizontal: 16,
//                       ),
//                       title: Text(
//                         'Order ID: ${order.id}',
//                         style: const TextStyle(fontWeight: FontWeight.bold),
//                       ),
//                       subtitle: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           const SizedBox(height: 4),
//                           Text(
//                             'Date: ${order.date != null ? '${order.date.day}/${order.date.month}/${order.date.year}' : 'N/A'}',
//                             style: const TextStyle(color: Colors.grey),
//                           ),
//                           const SizedBox(height: 4),
//                           Text(
//                             'Total: \$${order.totalAmount.toStringAsFixed(2)}',
//                             style: const TextStyle(color: Colors.deepOrange),
//                           ),
//                         ],
//                       ),
//                       trailing: const Icon(
//                         Icons.arrow_forward_ios_rounded,
//                         size: 18,
//                       ),
//                       onTap: () {
//                         Navigator.push(
//                           context,
//                           MaterialPageRoute(
//                             builder:
//                                 (_) => OrderConfirmationScreen(order: order),
//                           ),
//                         );
//                       },
//                     ),
//                   );
//                 },
//               ),
//     );
//   }
// }
