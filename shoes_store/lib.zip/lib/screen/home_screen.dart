import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';
import 'package:shoes_store/screen/cart_screen.dart';
import 'package:shoes_store/screen/my_order_screen.dart' show MyOrderScreen;
import 'package:shoes_store/services/api_service.dart';
import '../model/list_image_screen.dart';
import 'order_product_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String selectedLabel = 'All';
  String? selectedLocation = 'Phnom, Cambodia';
  final ScrollController _scrollController = ScrollController();
  int _currentIndex = 0;
  bool _isLoading = true;
  List<ImageData> popularItems = [];
  List<ImageItems> allItems = [];

  @override
  void initState() {
    super.initState();
    _fetchShoes();
    _startAutoScroll();
  }

  Future<void> _fetchShoes() async {
    try {
      final shoes = await ApiService.fetchShoes();
      print('Fetched shoes: $shoes'); // Debug log
      if (shoes.isNotEmpty) {
        setState(() {
          popularItems = shoes.take(12).toList(); // Limit to 12 popular items
          allItems =
              shoes
                  .map(
                    (shoe) => ImageItems(
                      id: shoe.id,
                      imagePath: shoe.imagePath,
                      brand: shoe.brand,
                      model: shoe.model,
                      price: shoe.price,
                      isFavorite: shoe.isFavorite,
                    ),
                  )
                  .toList();
          _isLoading = false;
        });
      } else {
        setState(() {
          _isLoading = false;
        });
        print('No shoes data received from API');
      }
    } catch (e) {
      print('Error fetching shoes: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _startAutoScroll() {
    Timer.periodic(Duration(seconds: 5), (timer) {
      if (_scrollController.hasClients) {
        if (_currentIndex < 6) {
          _currentIndex++;
        } else {
          _currentIndex = 0;
        }
        double offset = _currentIndex * 370.0;
        _scrollController.animateTo(
          offset,
          duration: Duration(seconds: 1),
          curve: Curves.easeInOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:
          _isLoading
              ? _buildLoadingAppBar()
              : PreferredSize(
                preferredSize: Size.fromHeight(130),
                child: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.all(25),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 10),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(left: 8.0),
                                  child: Text(
                                    'Location',
                                    style: TextStyle(fontSize: 15),
                                  ),
                                ),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.location_on,
                                      color: Colors.black87,
                                    ),
                                    SizedBox(width: 5),
                                    DropdownButton<String>(
                                      value: selectedLocation,
                                      items:
                                          <String>[
                                            'Phnom, Cambodia',
                                            'New York, USA',
                                            'London, UK',
                                            'Tokyo, Japan',
                                            'Sydney, Australia',
                                          ].map((String value) {
                                            return DropdownMenuItem<String>(
                                              value: value,
                                              child: Row(
                                                children: [
                                                  Text(
                                                    value,
                                                    style: TextStyle(
                                                      fontSize: 16,
                                                      color: Colors.black87,
                                                    ),
                                                  ),
                                                  SizedBox(width: 5),
                                                  Icon(
                                                    Icons.arrow_drop_down,
                                                    color: Colors.black87,
                                                    size: 20,
                                                  ),
                                                ],
                                              ),
                                            );
                                          }).toList(),
                                      onChanged: (String? newValue) {
                                        if (newValue != null) {
                                          setState(() {
                                            selectedLocation = newValue;
                                          });
                                        }
                                      },
                                      underline: Container(),
                                      icon: SizedBox.shrink(),
                                    ),
                                    SizedBox(width: 100),
                                    Icon(
                                      Icons.notifications_none,
                                      color: Colors.black87,
                                    ),
                                    Stack(
                                      children: [
                                        IconButton(
                                          icon: const Icon(
                                            Icons.shopping_bag_outlined,
                                          ),
                                          onPressed: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder:
                                                    (context) =>
                                                        const CartScreen(),
                                              ),
                                            );
                                          },
                                        ),
                                        if (OrderProductScreen
                                                .totalCartItemCount >
                                            0)
                                          Positioned(
                                            right: 4,
                                            top: 4,
                                            child: Container(
                                              padding: const EdgeInsets.all(2),
                                              decoration: BoxDecoration(
                                                color: Colors.red,
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                              ),
                                              constraints: const BoxConstraints(
                                                minWidth: 16,
                                                minHeight: 16,
                                              ),
                                              child: Text(
                                                '${OrderProductScreen.totalCartItemCount}',
                                                style: const TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 10,
                                                ),
                                                textAlign: TextAlign.center,
                                              ),
                                            ),
                                          ),
                                      ],
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Expanded(
                              child: Container(
                                height: 45,
                                padding: EdgeInsets.symmetric(horizontal: 15),
                                decoration: BoxDecoration(
                                  color: Colors.grey[200],
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Row(
                                  children: [
                                    Icon(Icons.search, color: Colors.grey),
                                    SizedBox(width: 8),
                                    Expanded(
                                      child: TextField(
                                        onChanged: (query) {},
                                        decoration: InputDecoration(
                                          hintText: 'Search',
                                          hintStyle: TextStyle(
                                            color: Colors.grey,
                                          ),
                                          border: InputBorder.none,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
      body:
          _isLoading
              ? _buildLoading()
              : ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  buildLastVersion(),
                  SizedBox(height: 25),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Popular Shoes',
                      style: TextStyle(
                        fontSize: 23,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  SizedBox(height: 15),
                  _buildPopular(),
                  SizedBox(height: 40),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Categories',
                      style: TextStyle(
                        fontSize: 23,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  SizedBox(height: 15),
                  _buildBrand(),
                  SizedBox(height: 20),
                  _buildAll(),
                ],
              ),
    );
  }

  PreferredSize _buildLoadingAppBar() {
    return PreferredSize(
      preferredSize: Size.fromHeight(130),
      child: Padding(
        padding: const EdgeInsets.all(25),
        child: Shimmer.fromColors(
          baseColor: Colors.grey.shade400,
          highlightColor: Colors.grey.shade100,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 10),
              Container(width: 80, height: 15, color: Colors.white),
              SizedBox(height: 8),
              Row(
                children: [
                  Container(width: 24, height: 24, color: Colors.white),
                  SizedBox(width: 5),
                  Container(width: 150, height: 20, color: Colors.white),
                  Spacer(),
                  Container(width: 24, height: 24, color: Colors.white),
                  SizedBox(width: 15),
                  Container(width: 24, height: 24, color: Colors.white),
                ],
              ),
              SizedBox(height: 20),
              Container(
                height: 45,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLoading() {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        SizedBox(
          height: 163,
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: List.generate(
                3,
                (index) => Padding(
                  padding: const EdgeInsets.all(2),
                  child: Shimmer.fromColors(
                    baseColor: Colors.grey.shade400,
                    highlightColor: Colors.grey.shade100,
                    child: Container(
                      height: 163,
                      width: 353,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            left: 24,
                            top: 30,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: 100,
                                  height: 32,
                                  color: Colors.white,
                                ),
                                SizedBox(height: 5),
                                Container(
                                  width: 150,
                                  height: 14,
                                  color: Colors.white,
                                ),
                                SizedBox(height: 16),
                                Container(
                                  width: 120,
                                  height: 40,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Positioned(
                            right: 5,
                            bottom: 5,
                            child: Container(
                              height: 140,
                              width: 140,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        SizedBox(height: 25),
        Shimmer.fromColors(
          baseColor: Colors.grey.shade400,
          highlightColor: Colors.grey.shade100,
          child: Container(width: 150, height: 23, color: Colors.white),
        ),
        SizedBox(height: 15),
        SizedBox(
          height: 170,
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: List.generate(
                3,
                (index) => Container(
                  width: 340,
                  margin: const EdgeInsets.only(right: 16),
                  child: Shimmer.fromColors(
                    baseColor: Colors.grey.shade400,
                    highlightColor: Colors.grey.shade100,
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withAlpha(51),
                            spreadRadius: 2,
                            blurRadius: 8,
                            offset: Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 20,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(height: 10),
                                  Container(
                                    width: 100,
                                    height: 20,
                                    color: Colors.white,
                                  ),
                                  SizedBox(height: 8),
                                  Container(
                                    width: 80,
                                    height: 16,
                                    color: Colors.white,
                                  ),
                                  SizedBox(height: 12),
                                  Container(
                                    width: 60,
                                    height: 22,
                                    color: Colors.white,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 16),
                            child: Container(
                              height: 140,
                              width: 140,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        SizedBox(height: 40),
        Shimmer.fromColors(
          baseColor: Colors.grey.shade400,
          highlightColor: Colors.grey.shade100,
          child: Container(width: 150, height: 23, color: Colors.white),
        ),
        SizedBox(height: 15),
        SizedBox(
          height: 40,
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: List.generate(
                5,
                (index) => Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: Shimmer.fromColors(
                    baseColor: Colors.grey.shade400,
                    highlightColor: Colors.grey.shade100,
                    child: Container(
                      width: 80,
                      height: 40,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(13),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        SizedBox(height: 20),
        GridView.builder(
          physics: NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          itemCount: 4,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 0.75,
          ),
          itemBuilder: (context, index) {
            return Shimmer.fromColors(
              baseColor: Colors.grey.shade400,
              highlightColor: Colors.grey.shade100,
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withAlpha(51),
                      spreadRadius: 2,
                      blurRadius: 8,
                      offset: Offset(0, 4),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Align(
                        alignment: Alignment.topRight,
                        child: Container(
                          width: 24,
                          height: 24,
                          color: Colors.white,
                        ),
                      ),
                      Center(
                        child: Container(
                          height: 90,
                          width: 90,
                          color: Colors.white,
                        ),
                      ),
                      SizedBox(height: 12),
                      Container(width: 80, height: 16, color: Colors.white),
                      SizedBox(height: 4),
                      Container(width: 100, height: 14, color: Colors.white),
                      Spacer(),
                      Container(width: 60, height: 16, color: Colors.white),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildPopular() {
    if (popularItems.isEmpty) {
      return Center(child: Text('No popular shoes available'));
    }
    return SizedBox(
      height: 170,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: List.generate(popularItems.length, (index) {
            final item = popularItems[index];
            return GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => OrderProductScreen(item: item),
                  ),
                );
              },
              child: Container(
                width: 340,
                margin: const EdgeInsets.only(right: 16),
                child: Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withAlpha(51),
                            spreadRadius: 2,
                            blurRadius: 8,
                            offset: Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 20,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(height: 10),
                                  Text(
                                    item.brand,
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  SizedBox(height: 8),
                                  Text(
                                    item.model,
                                    style: TextStyle(
                                      fontSize: 16,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                  SizedBox(height: 12),
                                  Text(
                                    item.price,
                                    style: TextStyle(
                                      fontSize: 22,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.deepOrange,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 16),
                            child: SizedBox(
                              height: 140,
                              width: 140,
                              child:
                                  item.imagePath.startsWith('http')
                                      ? Image.network(
                                        item.imagePath,
                                        fit: BoxFit.contain,
                                        errorBuilder: (
                                          context,
                                          error,
                                          stackTrace,
                                        ) {
                                          print(
                                            'Image network error for ${item.imagePath}: $error',
                                          );
                                          return Icon(
                                            Icons.broken_image,
                                            size: 50,
                                            color: Colors.grey,
                                          );
                                        },
                                      )
                                      : Image.asset(
                                        item.imagePath,
                                        fit: BoxFit.contain,
                                        errorBuilder: (
                                          context,
                                          error,
                                          stackTrace,
                                        ) {
                                          print(
                                            'Image asset error for ${item.imagePath}: $error',
                                          );
                                          return Icon(
                                            Icons.broken_image,
                                            size: 50,
                                            color: Colors.grey,
                                          );
                                        },
                                      ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      top: 10,
                      right: 10,
                      child: GestureDetector(
                        onTap: () async {
                          setState(() {
                            item.isFavorite = !item.isFavorite;
                          });
                          try {
                            await ApiService.toggleFavorite(
                              item.id!,
                              item.isFavorite,
                            );
                          } catch (e) {
                            print('Failed to toggle favorite: $e');
                            setState(() {
                              item.isFavorite =
                                  !item.isFavorite; // Revert on failure
                            });
                          }
                        },
                        child: Icon(
                          item.isFavorite
                              ? Icons.favorite
                              : Icons.favorite_border,
                          color: item.isFavorite ? Colors.red : Colors.grey,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          }),
        ),
      ),
    );
  }

  Widget buildLastVersion() {
    final bannerItems = [
      {
        'image': 'assets/Last_version_one.png',
        'discount': '10%',
        'item': popularItems.isNotEmpty ? popularItems[0] : null,
      },
      {
        'image': 'assets/Last_version_two.png',
        'discount': '15%',
        'item': popularItems.length > 1 ? popularItems[1] : null,
      },
      {
        'image': 'assets/Last_version_three.png',
        'discount': '10%',
        'item': popularItems.length > 2 ? popularItems[2] : null,
      },
      {
        'image': 'assets/Last_version_four.png',
        'discount': '5%',
        'item': popularItems.length > 3 ? popularItems[3] : null,
      },
      {
        'image': 'assets/Last_version_five.png',
        'discount': '10%',
        'item': popularItems.length > 4 ? popularItems[4] : null,
      },
      {
        'image': 'assets/Last_version_six.png',
        'discount': '15%',
        'item': popularItems.length > 5 ? popularItems[5] : null,
      },
    ];

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      controller: _scrollController,
      child: Row(
        children:
            bannerItems.map((banner) {
              final item = banner['item'] as ImageData?;
              if (item == null) return SizedBox.shrink();
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.5),
                child: buildImage(
                  banner['image'] as String,
                  banner['discount'] as String,
                  item,
                ),
              );
            }).toList(),
      ),
    );
  }

  Widget buildImage(String imagePath, String discountText, ImageData item) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => OrderProductScreen(item: item),
          ),
        );
      },
      child: Container(
        height: 163,
        width: 353,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color.fromARGB(255, 203, 32, 19), Colors.deepOrange],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Stack(
          children: [
            Positioned(
              left: 24,
              top: 30,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: discountText,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 32,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        TextSpan(
                          text: ' Discount',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    'on your first purchase',
                    style: TextStyle(color: Colors.white, fontSize: 14),
                  ),
                  SizedBox(height: 16),
                  SizedBox(
                    height: 40,
                    width: 120,
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        backgroundColor: Colors.white.withAlpha(229),
                        side: BorderSide(color: Colors.white.withAlpha(204)),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder:
                                (context) => OrderProductScreen(item: item),
                          ),
                        );
                      },
                      child: Text(
                        "Shop now",
                        style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              right: 5,
              bottom: 5,
              child: Image.asset(
                imagePath,
                height: 140,
                width: 140,
                fit: BoxFit.contain,
                errorBuilder: (context, error, stackTrace) {
                  print('Banner image error for $imagePath: $error');
                  return Icon(Icons.broken_image, size: 50, color: Colors.grey);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBrand() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Align(
        alignment: Alignment.topCenter,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            buildButton('All'),
            SizedBox(width: 10),
            buildButton('Nike'),
            SizedBox(width: 10),
            buildButton('Adidas'),
            SizedBox(width: 10),
            buildButton('Puma'),
            SizedBox(width: 10),
            buildButton('Reebok'),
            SizedBox(width: 10),
            buildButton('Skechers'),
            SizedBox(width: 10),
            buildButton('Under Armour'),
            SizedBox(width: 10),
            buildButton('New Balance'),
            SizedBox(width: 10),
            buildButton('Converse'),
            SizedBox(width: 10),
            buildButton('Vans'),
            SizedBox(width: 10),
            buildButton('Asics'),
          ],
        ),
      ),
    );
  }

  Widget buildButton(String label) {
    bool isSelected = selectedLabel == label;
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(13),
        color: isSelected ? Colors.deepOrange[700] : Colors.grey[200],
      ),
      child: TextButton(
        onPressed: () {
          setState(() {
            selectedLabel = label;
          });
        },
        child: Text(
          label,
          style: TextStyle(
            fontSize: 18,
            fontFamily: 'Vollkorn',
            fontWeight: FontWeight.bold,
            color: isSelected ? Colors.white : Colors.black,
          ),
        ),
      ),
    );
  }

  Widget _buildAll() {
    List<ImageItems> filteredItems =
        selectedLabel == 'All'
            ? allItems
            : allItems.where((item) => item.brand == selectedLabel).toList();

    if (filteredItems.isEmpty) {
      return Center(child: Text('No shoes available in this category'));
    }
    return GridView.builder(
      physics: NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: filteredItems.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 0.75,
      ),
      itemBuilder: (context, index) {
        final item = filteredItems[index];
        return GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => OrderProductScreen(item: item),
              ),
            );
          },
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withAlpha(51),
                  spreadRadius: 2,
                  blurRadius: 8,
                  offset: Offset(0, 4),
                ),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Align(
                    alignment: Alignment.topRight,
                    child: GestureDetector(
                      onTap: () async {
                        setState(() {
                          item.isFavorite = !item.isFavorite;
                        });
                        try {
                          await ApiService.toggleFavorite(
                            item.id!,
                            item.isFavorite,
                          );
                        } catch (e) {
                          print('Failed to toggle favorite: $e');
                          setState(() {
                            item.isFavorite =
                                !item.isFavorite; // Revert on failure
                          });
                        }
                      },
                      child: Icon(
                        item.isFavorite
                            ? Icons.favorite
                            : Icons.favorite_border,
                        color: item.isFavorite ? Colors.red : Colors.grey,
                      ),
                    ),
                  ),
                  Center(
                    child: SizedBox(
                      height: 90,
                      child:
                          item.imagePath.startsWith('http')
                              ? Image.network(
                                item.imagePath,
                                fit: BoxFit.contain,
                                errorBuilder: (context, error, stackTrace) {
                                  print(
                                    'Image network error for ${item.imagePath}: $error',
                                  );
                                  return Icon(
                                    Icons.broken_image,
                                    size: 50,
                                    color: Colors.grey,
                                  );
                                },
                              )
                              : Image.asset(
                                item.imagePath,
                                fit: BoxFit.contain,
                                errorBuilder: (context, error, stackTrace) {
                                  print(
                                    'Image asset error for ${item.imagePath}: $error',
                                  );
                                  return Icon(
                                    Icons.broken_image,
                                    size: 50,
                                    color: Colors.grey,
                                  );
                                },
                              ),
                    ),
                  ),
                  SizedBox(height: 12),
                  Text(
                    item.brand,
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 4),
                  Text(
                    item.model,
                    style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  Spacer(),
                  Text(
                    item.price,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.deepOrange,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
