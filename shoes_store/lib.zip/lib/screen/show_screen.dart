// ignore_for_file: use_build_context_synchronously

import 'package:flutter/material.dart';

import 'main_screen.dart';

class ShowScreen extends StatefulWidget {
  const ShowScreen({super.key});

  @override
  State<ShowScreen> createState() => _ShowScreenState();
}

class _ShowScreenState extends State<ShowScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => MainScreen(),
        ), // Replace with your desired screen
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          ColorFiltered(
            colorFilter: ColorFilter.mode(
              Color.fromRGBO(30, 30, 30, 0.3),
              BlendMode.srcATop,
            ),

            child: Image.asset(
              'assets/show_image.jpg', // Make sure this path is correct
              fit: BoxFit.cover,
            ),
          ),
          Center(
            child: ShaderMask(
              shaderCallback:
                  (bounds) => LinearGradient(
                    colors: [Colors.orange, Colors.pinkAccent],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ).createShader(
                    Rect.fromLTWH(0, 0, bounds.width, bounds.height),
                  ),
              child: Text(
                'Shoes Store',
                style: TextStyle(
                  fontFamily: 'Pacifico',
                  fontSize: 36,
                  color: Colors.white, // this color is overridden by shader
                ),
              ),
            ),
          ),

          // Centering the logo and text
        ],
      ),
    );
  }
}
