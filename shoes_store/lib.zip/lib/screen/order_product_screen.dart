import 'package:flutter/material.dart';
import 'package:shoes_store/model/OrderItem.dart';
import 'package:shoes_store/model/ProductVariant.dart';
import 'package:shoes_store/model/list_image_screen.dart';
import 'package:shoes_store/screen/cart_screen.dart';
import 'package:shoes_store/services/api_service.dart';

class OrderProductScreen extends StatefulWidget {
  final ImageData item;
  static int totalCartItemCount = 0;
  static String? cartId;

  const OrderProductScreen({super.key, required this.item});

  @override
  State<OrderProductScreen> createState() => _OrderProductScreenState();
}

class _OrderProductScreenState extends State<OrderProductScreen> {
  String _selectedColor = '';
  String _selectedSize = '';
  int _quantity = 1;
  List<ProductVariant> _variants = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetchVariants();
  }

  Future<void> _fetchVariants() async {
    try {
      final variants = await ApiService.fetchVariants(widget.item.id!);
      setState(() {
        _variants = variants;
        if (variants.isNotEmpty) {
          _selectedColor = variants.first.color ?? ''; // Set initial color
        }
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _isLoading = false;
      });
    }
  }

  // Construct image URL based on selected color (adjust based on API)
  String _getImageUrlForColor(String color) {
    // Example: Assume images are named like /storage/images/black_shoe.jpg
    final baseUrl = 'http://10.0.2.2:8000/storage/images/';
    final colorLower = color.toLowerCase();
    return '$baseUrl${colorLower}_shoe.jpg'; // Adjust filename logic as per your storage
  }

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    final filteredVariants =
        _variants.where((v) => v.shoeId == item.id).toList();
    final colors = filteredVariants.map((v) => v.color).toSet().toList();
    final sizes =
        filteredVariants
            .where((v) => _selectedColor.isEmpty || v.color == _selectedColor)
            .map((v) => v.size)
            .toSet()
            .toList();

    double basePrice =
        double.tryParse(
          item.price.toString().replaceAll(RegExp(r'[^\d.]'), ''),
        ) ??
        0.0;
    final double totalPrice = basePrice * _quantity;

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          Stack(
            children: [
              IconButton(
                icon: const Icon(Icons.shopping_bag_outlined),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const CartScreen()),
                  );
                },
              ),
              if (OrderProductScreen.totalCartItemCount > 0)
                Positioned(
                  right: 8,
                  top: 8,
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    constraints: const BoxConstraints(
                      minWidth: 16,
                      minHeight: 16,
                    ),
                    child: Text(
                      '${OrderProductScreen.totalCartItemCount}',
                      style: const TextStyle(color: Colors.white, fontSize: 10),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text('Error: $_error'))
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(
                          child: Image.network(
                            _selectedColor.isNotEmpty
                                ? _getImageUrlForColor(_selectedColor)
                                : item.imagePath,
                            height: 300,
                            fit: BoxFit.contain,
                            errorBuilder: (context, error, stackTrace) =>
                                const Icon(
                              Icons.broken_image,
                              size: 150,
                              color: Colors.grey,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),
                      Text(
                        '${item.brand} ${item.model}',
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Row(
                        children: [
                          Icon(Icons.star, color: Colors.grey, size: 20),
                          Text(
                            ' 5.0 (1154 Reviews)',
                            style: TextStyle(fontSize: 16),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'Created for the hardwood but taken to the streets, the \u201880s b-ball icon returns with classic details and throwback hoops flair. Read More',
                        style: TextStyle(fontSize: 16, height: 1.5),
                      ),
                      TextButton(
                        onPressed: () {},
                        child: const Text('Read More'),
                        style: TextButton.styleFrom(
                          padding: EdgeInsets.zero,
                          minimumSize: const Size(50, 30),
                        ),
                      ),
                      const SizedBox(height: 24),
                      const Text(
                        'Select Colour:',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        children: colors
                            .map(
                              (color) => ChoiceChip(
                                label: Text(color ?? 'N/A'),
                                selected: _selectedColor == color,
                                onSelected: (selected) {
                                  setState(() {
                                    _selectedColor =
                                        selected ? color ?? '' : '';
                                    _selectedSize = ''; // Reset size when color changes
                                  });
                                },
                                selectedColor: _getColorChipColor(
                                  color ?? 'grey',
                                ),
                                backgroundColor: Colors.grey[300],
                              ),
                            )
                            .toList(),
                      ),
                      const SizedBox(height: 16),
                      if (_selectedColor.isNotEmpty) ...[
                        const Text(
                          'Size:',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 8,
                          children: sizes
                              .map(
                                (size) => ChoiceChip(
                                  label: Text(size ?? 'N/A'),
                                  selected: _selectedSize == size,
                                  onSelected: (selected) {
                                    setState(() {
                                      _selectedSize = selected ? size ?? '' : '';
                                    });
                                  },
                                  selectedColor: Colors.deepOrange,
                                  backgroundColor: Colors.grey[300],
                                ),
                              )
                              .toList(),
                        ),
                      ],
                      const SizedBox(height: 24),
                      Row(
                        children: [
                          const Text(
                            'Quantity:',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(width: 16),
                          Row(
                            children: [
                              IconButton(
                                icon: const Icon(Icons.remove),
                                onPressed: () {
                                  if (_quantity > 1) {
                                    setState(() {
                                      _quantity--;
                                    });
                                  }
                                },
                              ),
                              Text(
                                '$_quantity',
                                style: const TextStyle(fontSize: 18),
                              ),
                              IconButton(
                                icon: const Icon(Icons.add),
                                onPressed: () {
                                  setState(() {
                                    _quantity++;
                                  });
                                },
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 24),
                      const Text(
                        'Price:',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        '\$${totalPrice.toStringAsFixed(2)}',
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 24),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () async {
                            if (_selectedColor.isEmpty || _selectedSize.isEmpty) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Please select color and size'),
                                ),
                              );
                              return;
                            }

                            final selectedVariant = _variants.firstWhere(
                              (v) =>
                                  v.color == _selectedColor &&
                                  v.size == _selectedSize,
                              orElse: () => throw Exception('Variant not found'),
                            );

                            try {
                              final cartId = await ApiService.addToCart(
                                shoeId: item.id!,
                                variantId: selectedVariant.id,
                                quantity: _quantity,
                                price: totalPrice, // Added missing price argument
                              );

                              setState(() {
                                OrderProductScreen.totalCartItemCount += _quantity;
                                OrderProductScreen.cartId = cartId;
                              });

                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const CartScreen(),
                                ),
                              );
                            } catch (e) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Error: $e')),
                              );
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.deepOrange,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          child: const Padding(
                            padding: EdgeInsets.symmetric(vertical: 16),
                            child: Text('Add to Cart'),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }

  Color _getColorChipColor(String colorName) {
    switch (colorName.toLowerCase()) {
      case 'yellow':
        return Colors.yellow;
      case 'milk':
      case 'white':
        return Colors.white;
      case 'red':
        return Colors.red;
      case 'grey':
      case 'gray':
        return Colors.grey;
      case 'black':
        return Colors.black;
      default:
        return Colors.grey;
    }
  }
}