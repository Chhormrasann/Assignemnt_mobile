import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shoes_store/model/OrderItem.dart';
import 'package:shoes_store/model/ProductVariant.dart';
import 'package:shoes_store/model/list_image_screen.dart';
import 'package:shoes_store/model/order.dart';

class ApiService {
  static const String baseUrl = 'http://10.0.2.2:8000/api';

  static Future<List<ImageData>> fetchShoes() async {
    try {
      final response = await http
          .get(Uri.parse('$baseUrl/shoes'))
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        List jsonResponse = json.decode(response.body);
        print('API Response (fetchShoes): $jsonResponse');
        return jsonResponse.map((data) => ImageData.fromJson(data)).toList();
      } else {
        print(
          'API Error (fetchShoes): ${response.statusCode} - ${response.body}',
        );
        throw Exception(
          'Failed to load shoes: ${response.statusCode} - ${response.body}',
        );
      }
    } catch (e) {
      print('Network Error (fetchShoes): $e');
      throw Exception('Failed to connect to API: $e');
    }
  }

  static Future<void> toggleFavorite(int id, bool isFavorite) async {
    try {
      final response = await http
          .put(
            Uri.parse('$baseUrl/shoes/$id'),
            headers: {'Content-Type': 'application/json'},
            body: json.encode({'is_favorite': isFavorite}),
          )
          .timeout(const Duration(seconds: 10));
      if (response.statusCode != 200) {
        print(
          'Toggle Favorite Error: ${response.statusCode} - ${response.body}',
        );
        throw Exception(
          'Failed to update favorite status: ${response.statusCode} - ${response.body}',
        );
      }
    } catch (e) {
      print('Network Error (toggleFavorite): $e');
      throw Exception('Failed to update favorite status: $e');
    }
  }

  static Future<List<ProductVariant>> fetchVariants(int shoeId) async {
    try {
      final response = await http
          .get(Uri.parse('$baseUrl/shoes/$shoeId/variants'))
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        List jsonResponse = json.decode(response.body);
        return jsonResponse
            .map((data) => ProductVariant.fromJson(data))
            .toList();
      } else {
        print(
          'API Error (fetchVariants): ${response.statusCode} - ${response.body}',
        );
        throw Exception(
          'Failed to load variants: ${response.statusCode} - ${response.body}',
        );
      }
    } catch (e) {
      print('Network Error (fetchVariants): $e');
      throw Exception('Failed to connect to API: $e');
    }
  }

  static Future<String> addToCart({
    required int shoeId,
    required int variantId,
    required int quantity,
    required double price,
  }) async {
    try {
      final response = await http
          .post(
            Uri.parse('$baseUrl/cart'),
            headers: {'Content-Type': 'application/json'},
            body: json.encode({
              'shoe_id': shoeId,
              'variant_id': variantId,
              'quantity': quantity,
              'price': price,
            }),
          )
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200 || response.statusCode == 201) {
        final jsonResponse = json.decode(response.body);
        if (jsonResponse.containsKey('cart_id')) {
          return jsonResponse['cart_id'].toString();
        } else if (jsonResponse.containsKey('cartId')) {
          return jsonResponse['cartId'].toString();
        } else {
          print('API Response (addToCart): ${response.body}');
          throw Exception('No cart_id or cartId in response: ${response.body}');
        }
      } else if (response.statusCode == 422) {
        final error = json.decode(response.body);
        print('Validation Error (addToCart): ${error['details']}');
        throw Exception('Validation failed: ${error['details']}');
      } else {
        print(
          'API Error (addToCart): ${response.statusCode} - ${response.body}',
        );
        throw Exception(
          'Failed to add to cart: ${response.statusCode} - ${response.body}',
        );
      }
    } catch (e) {
      print('Network Error (addToCart): $e');
      throw Exception('Failed to connect to API: $e');
    }
  }

  static Future<List<OrderItem>> getCart(String cartId) async {
    try {
      final response = await http
          .get(Uri.parse('$baseUrl/cart/$cartId'))
          .timeout(const Duration(seconds: 10));
      print('Raw API Response (getCart): ${response.body}');
      if (response.statusCode == 200) {
        dynamic jsonResponse = json.decode(response.body);
        if (jsonResponse is! Map || jsonResponse['items'] == null) {
          throw FormatException('Invalid response structure');
        }
        print('Decoded API Response (getCart): $jsonResponse');
        if (jsonResponse['items'] is List) {
          return (jsonResponse['items'] as List)
              .map((item) => OrderItem.fromJson(item))
              .toList();
        } else {
          throw Exception('Items field is not a list: $jsonResponse');
        }
      } else {
        print('API Error (getCart): ${response.statusCode} - ${response.body}');
        throw Exception(
          'Failed to load cart: ${response.statusCode} - ${response.body}',
        );
      }
    } catch (e) {
      print('Network Error (getCart): $e');
      throw Exception('Failed to connect to API: $e');
    }
  }

  static Future<String> createOrder({
    required double totalAmount,
    required List<Map<String, dynamic>> items,
  }) async {
    try {
      final response = await http
          .post(
            Uri.parse('$baseUrl/orders'),
            headers: {'Content-Type': 'application/json'},
            body: json.encode({'total_amount': totalAmount, 'items': items}),
          )
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200 || response.statusCode == 201) {
        final jsonResponse = json.decode(response.body);
        if (jsonResponse.containsKey('order_id')) {
          return jsonResponse['order_id'].toString();
        } else {
          print('API Response (createOrder): ${response.body}');
          throw Exception('No order_id in response: ${response.body}');
        }
      } else {
        print(
          'API Error (createOrder): ${response.statusCode} - ${response.body}',
        );
        throw Exception(
          'Failed to create order: ${response.statusCode} - ${response.body}',
        );
      }
    } catch (e) {
      print('Network Error (createOrder): $e');
      throw Exception('Failed to connect to API: $e');
    }
  }

  static Future<List<Order>> getOrders() async {
    try {
      final response = await http
          .get(Uri.parse('$baseUrl/orders'))
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final List<dynamic> jsonResponse = json.decode(response.body);
        return jsonResponse.map((json) => Order.fromJson(json)).toList();
      } else {
        print(
          'API Error (getOrders): ${response.statusCode} - ${response.body}',
        );
        return []; // Return empty list on non-200 status
      }
    } catch (e) {
      print('Network Error (getOrders): $e');
      return []; // Return empty list on exception
    }
  }
}
