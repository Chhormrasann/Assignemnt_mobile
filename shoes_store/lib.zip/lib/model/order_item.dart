class OrderItem {
  final String id;
  final String orderId;
  final String shoeId;
  final String variantId;
  final String productName;
  final String imageUrl;
  final int quantity;
  final double price;
  final String size;
  final String color;

  OrderItem({
    required this.id,
    required this.orderId,
    required this.shoeId,
    required this.variantId,
    required this.productName,
    required this.imageUrl,
    required this.quantity,
    required this.price,
    required this.size,
    required this.color,
  });

  factory OrderItem.fromJson(Map<String, dynamic> json) {
    String imagePath = json['variant']?['image_url'] ?? '';
    String baseUrl = 'http://10.0.2.2:8000';
    if (imagePath.isNotEmpty && !imagePath.startsWith('/')) {
      imagePath = '/$imagePath'; // Ensure path starts with /
    }
    return OrderItem(
      id: json['id'].toString(),
      orderId: json['order_id'].toString(),
      shoeId: json['shoe_id'].toString(),
      variantId: json['variant_id'].toString(),
      productName:
          '${json['shoe']?['brand'] ?? 'Unknown'} ${json['shoe']?['model'] ?? 'Product'}',
      imageUrl: imagePath.isNotEmpty ? '$baseUrl$imagePath' : '',
      quantity: json['quantity'] ?? 0,
      price: double.parse((json['price'] ?? '0.0').toString()),
      size: json['variant']?['size'] ?? 'N/A',
      color: json['variant']?['color'] ?? 'N/A',
    );
  }
}
