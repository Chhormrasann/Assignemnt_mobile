import 'package:shoes_store/model/OrderItem.dart'; // As provided

class Order {
  final String id;
  final DateTime date;
  final double totalAmount;
  final String status;
  final List<OrderItem> items;

  Order({
    required this.id,
    required this.date,
    required this.totalAmount,
    required this.status,
    required this.items,
  });

  factory Order.fromJson(Map<String, dynamic> json) {
    return Order(
      id: json['id'].toString(),
      date: DateTime.parse(json['created_at']),
      totalAmount: double.parse(json['total_amount'].toString()),
      status: json['status'],
      items:
          (json['items'] as List)
              .map((item) => OrderItem.fromJson(item))
              .toList(),
    );
  }
}
