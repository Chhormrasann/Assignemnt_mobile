class ImageData {
  final int? id;
  final String imagePath;
  final String brand;
  final String model;
  final String price;
  bool isFavorite;

  ImageData({
    this.id,
    required this.imagePath,
    required this.brand,
    required this.model,
    required this.price,
    this.isFavorite = false,
  });

  factory ImageData.fromJson(Map<String, dynamic> json) {
    return ImageData(
      id: json['id'],
      imagePath: json['image_path'],
      brand: json['brand'],
      model: json['model'],
      price: json['price'],
      isFavorite: json['is_favorite'] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'image_path': imagePath,
      'brand': brand,
      'model': model,
      'price': price,
      'is_favorite': isFavorite,
    };
  }
}

class ImageItems extends ImageData {
  ImageItems({
    int? id,
    required String imagePath,
    required String brand,
    required String model,
    required String price,
    bool isFavorite = false,
  }) : super(
         id: id,
         imagePath: imagePath,
         brand: brand,
         model: model,
         price: price,
         isFavorite: isFavorite,
       );
}
