class ProductVariant {
  final int id;
  final int shoeId;
  final String color;
  final String size;
  final int stock;
  final String imageUrl;

  ProductVariant({
    required this.id,
    required this.shoeId,
    required this.color,
    required this.size,
    required this.stock,
    required this.imageUrl,
  });

  factory ProductVariant.fromJson(Map<String, dynamic> json) {
    return ProductVariant(
      id: json['id'],
      shoeId: json['shoe_id'],
      color: json['color'],
      size: json['size'],
      stock: json['stock'],
      imageUrl: json['image_url'], // Map the image_url from API response
    );
  }
}
