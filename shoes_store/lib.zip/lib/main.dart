import 'package:flutter/material.dart';
import 'package:shoes_store/screen/show_screen.dart';

import 'model/navigation_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Shoes Store',
      home: ShowScreen(),
    );
  }
}
